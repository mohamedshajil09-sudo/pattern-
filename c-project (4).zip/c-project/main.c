// Online C compiler (editor)
// Write and run C online using this editor.

#include <stdio.h>

int main() {
int i,n,j;
printf ( "enter the number :");
scanf( "%d",&n);    
    for (i=1;i<=n;i++){
        for(j=1;j<=i;j++){
            printf("%d",j); } 
    printf("\n");    
    }    
    return 0;
}
